import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DonorDashboard } from './pages/DonorDashboard';
import { NGODashboard } from './pages/NGODashboard';
import { TrackingPage } from './pages/TrackingPage';
import { AdminDashboard } from './pages/AdminDashboard';

export default function App() {
  // Mock authentication - in real app, this would use context/state management
  const getUserRole = (pathname: string) => {
    if (pathname.includes('admin')) return 'admin';
    if (pathname.includes('donor-dashboard')) return 'donor';
    if (pathname.includes('ngo-dashboard')) return 'ngo';
    if (pathname.includes('tracking')) return 'donor'; // Both can access
    return null;
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-white">
        <Routes>
          {/* Public Routes - Landing/Auth */}
          <Route
            path="/"
            element={
              <>
                <Header isAuthenticated={false} />
                <main className="flex-1">
                  <LandingPage />
                </main>
                <Footer />
              </>
            }
          />
          <Route
            path="/login"
            element={
              <>
                <Header isAuthenticated={false} />
                <main className="flex-1">
                  <LoginPage />
                </main>
                <Footer />
              </>
            }
          />
          <Route
            path="/register"
            element={
              <>
                <Header isAuthenticated={false} />
                <main className="flex-1">
                  <RegisterPage />
                </main>
                <Footer />
              </>
            }
          />

          {/* Donor Dashboard */}
          <Route
            path="/donor-dashboard"
            element={
              <>
                <Header isAuthenticated={true} userRole="donor" />
                <main className="flex-1">
                  <DonorDashboard />
                </main>
                <Footer />
              </>
            }
          />

          {/* NGO/Volunteer Dashboard */}
          <Route
            path="/ngo-dashboard"
            element={
              <>
                <Header isAuthenticated={true} userRole="ngo" />
                <main className="flex-1">
                  <NGODashboard />
                </main>
                <Footer />
              </>
            }
          />

          {/* Tracking Page */}
          <Route
            path="/tracking"
            element={
              <>
                <Header isAuthenticated={true} userRole="donor" />
                <main className="flex-1">
                  <TrackingPage />
                </main>
                <Footer />
              </>
            }
          />

          {/* Admin Dashboard */}
          <Route
            path="/admin"
            element={
              <>
                <Header isAuthenticated={true} userRole="admin" />
                <main className="flex-1">
                  <AdminDashboard />
                </main>
                <Footer />
              </>
            }
          />

          {/* Catch all - redirect to home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}
