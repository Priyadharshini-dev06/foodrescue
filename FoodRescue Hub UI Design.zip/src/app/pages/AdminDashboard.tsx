import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, Users, Package, CheckCircle2, Activity } from 'lucide-react';

export function AdminDashboard() {
  const stats = [
    {
      title: 'Total Food Rescued',
      value: '12,450',
      unit: 'kg',
      change: '+12.5%',
      trend: 'up',
      icon: Package,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      title: 'Active Users',
      value: '1,234',
      unit: 'users',
      change: '+8.2%',
      trend: 'up',
      icon: Users,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
    },
    {
      title: 'Successful Deliveries',
      value: '856',
      unit: 'deliveries',
      change: '+15.3%',
      trend: 'up',
      icon: CheckCircle2,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      title: 'Active Listings',
      value: '47',
      unit: 'listings',
      change: '-3.1%',
      trend: 'down',
      icon: Activity,
      color: 'text-gray-600',
      bgColor: 'bg-gray-100',
    },
  ];

  const weeklyData = [
    { day: 'Mon', donations: 45, pickups: 42 },
    { day: 'Tue', donations: 52, pickups: 48 },
    { day: 'Wed', donations: 38, pickups: 36 },
    { day: 'Thu', donations: 61, pickups: 58 },
    { day: 'Fri', donations: 55, pickups: 52 },
    { day: 'Sat', donations: 48, pickups: 45 },
    { day: 'Sun', donations: 42, pickups: 40 },
  ];

  const monthlyTrend = [
    { month: 'Jan', meals: 2400 },
    { month: 'Feb', meals: 2800 },
    { month: 'Mar', meals: 3200 },
    { month: 'Apr', meals: 2900 },
    { month: 'May', meals: 3600 },
    { month: 'Jun', meals: 4100 },
  ];

  const recentDonations = [
    {
      id: 'D001',
      donor: 'Green Valley Restaurant',
      foodType: 'Prepared Meals',
      quantity: '50 servings',
      recipient: 'Hope Foundation NGO',
      status: 'delivered',
      timestamp: '2026-02-05 16:30',
    },
    {
      id: 'D002',
      donor: 'Sweet Delights Bakery',
      foodType: 'Bakery Items',
      quantity: '30 items',
      recipient: 'Community Kitchen',
      status: 'picked-up',
      timestamp: '2026-02-05 15:45',
    },
    {
      id: 'D003',
      donor: 'Grand Hotel Banquet',
      foodType: 'Fresh Produce',
      quantity: '20 kg',
      recipient: 'Food for All',
      status: 'accepted',
      timestamp: '2026-02-05 14:20',
    },
    {
      id: 'D004',
      donor: 'City Convention Center',
      foodType: 'Packaged Food',
      quantity: '100 items',
      recipient: 'Pending',
      status: 'available',
      timestamp: '2026-02-05 13:15',
    },
    {
      id: 'D005',
      donor: 'Ocean View Café',
      foodType: 'Prepared Meals',
      quantity: '35 servings',
      recipient: 'Meals on Wheels',
      status: 'delivered',
      timestamp: '2026-02-05 12:00',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'accepted':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'picked-up':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Monitor platform performance and manage operations</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                      <div className="flex items-baseline gap-2">
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                        <span className="text-sm text-gray-500">{stat.unit}</span>
                      </div>
                      <div className="flex items-center gap-1 mt-2">
                        <TrendingUp
                          className={`w-4 h-4 ${
                            stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                          } ${stat.trend === 'down' ? 'rotate-180' : ''}`}
                        />
                        <span
                          className={`text-sm ${
                            stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                          }`}
                        >
                          {stat.change}
                        </span>
                        <span className="text-xs text-gray-500">vs last month</span>
                      </div>
                    </div>
                    <div className={`${stat.bgColor} p-3 rounded-lg`}>
                      <Icon className={`w-6 h-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Weekly Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly Activity</CardTitle>
              <CardDescription>Donations vs Pickups over the last 7 days</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="donations" fill="#16a34a" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="pickups" fill="#ea580c" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Monthly Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Meals Rescued Trend</CardTitle>
              <CardDescription>Total meals rescued per month</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="meals"
                    stroke="#16a34a"
                    strokeWidth={2}
                    dot={{ fill: '#16a34a', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Recent Donations Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Donations</CardTitle>
            <CardDescription>Monitor all donations and pickups in real-time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Donor</TableHead>
                    <TableHead>Food Type</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentDonations.map((donation) => (
                    <TableRow key={donation.id}>
                      <TableCell className="font-medium">{donation.id}</TableCell>
                      <TableCell>{donation.donor}</TableCell>
                      <TableCell>{donation.foodType}</TableCell>
                      <TableCell>{donation.quantity}</TableCell>
                      <TableCell>{donation.recipient}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(donation.status)}>
                          {donation.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">{donation.timestamp}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
