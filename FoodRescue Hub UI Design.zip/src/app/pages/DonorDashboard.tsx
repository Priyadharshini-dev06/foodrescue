import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Plus, Clock, CheckCircle2, Package, MapPin, Calendar } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';

interface FoodListing {
  id: string;
  foodType: string;
  quantity: string;
  location: string;
  expiryTime: string;
  notes: string;
  status: 'available' | 'accepted' | 'collected';
  postedAt: string;
}

export function DonorDashboard() {
  const [showForm, setShowForm] = useState(false);
  const [listings, setListings] = useState<FoodListing[]>([
    {
      id: '1',
      foodType: 'Prepared Meals',
      quantity: '50 servings',
      location: '123 Main St, Downtown',
      expiryTime: '2026-02-05T20:00',
      notes: 'Fresh pasta and salad from dinner service',
      status: 'accepted',
      postedAt: '2026-02-05T15:30',
    },
    {
      id: '2',
      foodType: 'Bakery Items',
      quantity: '30 items',
      location: '123 Main St, Downtown',
      expiryTime: '2026-02-06T10:00',
      notes: 'Assorted pastries and bread',
      status: 'available',
      postedAt: '2026-02-05T16:00',
    },
    {
      id: '3',
      foodType: 'Fresh Produce',
      quantity: '20 kg',
      location: '123 Main St, Downtown',
      expiryTime: '2026-02-07T18:00',
      notes: 'Various vegetables from event catering',
      status: 'collected',
      postedAt: '2026-02-04T12:00',
    },
  ]);

  const [formData, setFormData] = useState({
    foodType: '',
    quantity: '',
    location: '',
    expiryTime: '',
    notes: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSelectChange = (value: string) => {
    setFormData({
      ...formData,
      foodType: value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newListing: FoodListing = {
      id: Date.now().toString(),
      ...formData,
      status: 'available',
      postedAt: new Date().toISOString(),
    };
    setListings([newListing, ...listings]);
    setFormData({
      foodType: '',
      quantity: '',
      location: '',
      expiryTime: '',
      notes: '',
    });
    setShowForm(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'accepted':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'collected':
        return 'bg-gray-100 text-gray-700 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available':
        return <Clock className="w-4 h-4" />;
      case 'accepted':
        return <Package className="w-4 h-4" />;
      case 'collected':
        return <CheckCircle2 className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const stats = [
    { label: 'Active Listings', value: listings.filter(l => l.status === 'available').length, color: 'text-green-600' },
    { label: 'Accepted Today', value: listings.filter(l => l.status === 'accepted').length, color: 'text-orange-600' },
    { label: 'Total Donated', value: listings.length, color: 'text-gray-600' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Donor Dashboard</h1>
          <p className="text-gray-600">Manage your food donations and track their impact</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className={`text-sm ${stat.color}`}>{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Post Form */}
        {showForm ? (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Post Surplus Food</CardTitle>
              <CardDescription>Fill in the details about the food you want to donate</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Food Type */}
                  <div className="space-y-2">
                    <Label htmlFor="foodType">Food Type</Label>
                    <Select onValueChange={handleSelectChange} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select food type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Prepared Meals">Prepared Meals</SelectItem>
                        <SelectItem value="Bakery Items">Bakery Items</SelectItem>
                        <SelectItem value="Fresh Produce">Fresh Produce</SelectItem>
                        <SelectItem value="Packaged Food">Packaged Food</SelectItem>
                        <SelectItem value="Dairy Products">Dairy Products</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Quantity */}
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      name="quantity"
                      placeholder="e.g., 50 servings, 20 kg"
                      value={formData.quantity}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {/* Pickup Location */}
                  <div className="space-y-2">
                    <Label htmlFor="location">Pickup Location</Label>
                    <Input
                      id="location"
                      name="location"
                      placeholder="Full address"
                      value={formData.location}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {/* Expiry Time */}
                  <div className="space-y-2">
                    <Label htmlFor="expiryTime">Best Before / Expiry Time</Label>
                    <Input
                      id="expiryTime"
                      name="expiryTime"
                      type="datetime-local"
                      value={formData.expiryTime}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder="Any special instructions, dietary information, or storage requirements..."
                    value={formData.notes}
                    onChange={handleInputChange}
                    rows={3}
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <Button type="submit" className="bg-green-600 hover:bg-green-700">
                    Post Listing
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Button
            onClick={() => setShowForm(true)}
            className="mb-8 bg-green-600 hover:bg-green-700"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Post New Food Donation
          </Button>
        )}

        {/* Listings */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-900">Your Listings</h2>
          
          {listings.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No listings yet. Post your first food donation!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {listings.map((listing) => (
                <Card key={listing.id}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-1">
                              {listing.foodType}
                            </h3>
                            <p className="text-gray-600">{listing.quantity}</p>
                          </div>
                          <Badge className={getStatusColor(listing.status)}>
                            {getStatusIcon(listing.status)}
                            <span className="ml-1 capitalize">{listing.status}</span>
                          </Badge>
                        </div>

                        <div className="space-y-2 text-sm text-gray-600">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            <span>{listing.location}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4" />
                            <span>Best before: {new Date(listing.expiryTime).toLocaleString()}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>Posted: {new Date(listing.postedAt).toLocaleString()}</span>
                          </div>
                        </div>

                        {listing.notes && (
                          <p className="mt-3 text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                            {listing.notes}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
