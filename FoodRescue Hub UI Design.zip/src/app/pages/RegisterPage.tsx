import { useState } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Heart, Mail, Lock, User, Building2, Users, UserCircle } from 'lucide-react';

export function RegisterPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialRole = searchParams.get('role') as 'donor' | 'ngo' | 'volunteer' | null;
  
  const [role, setRole] = useState<'donor' | 'ngo' | 'volunteer'>(initialRole || 'donor');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    organization: '',
  });

  const roles = [
    {
      value: 'donor',
      label: 'Donor',
      icon: Building2,
      description: 'Restaurant, Hotel, or Event Organizer',
      color: 'text-green-600 bg-green-50 border-green-200',
    },
    {
      value: 'ngo',
      label: 'NGO',
      icon: Users,
      description: 'Non-profit Organization',
      color: 'text-orange-600 bg-orange-50 border-orange-200',
    },
    {
      value: 'volunteer',
      label: 'Volunteer',
      icon: UserCircle,
      description: 'Individual Volunteer',
      color: 'text-green-600 bg-green-50 border-green-200',
    },
  ];

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock registration - in real app, this would create account
    if (role === 'donor') {
      navigate('/donor-dashboard');
    } else {
      navigate('/ngo-dashboard');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12 bg-gradient-to-br from-green-50 via-white to-orange-50">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-green-500 to-green-600 p-3 rounded-xl">
              <Heart className="w-8 h-8 text-white" fill="white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">FoodRescue Hub</span>
          </div>
        </div>

        <Card className="border-0 shadow-xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Create Your Account</CardTitle>
            <CardDescription className="text-center">
              Join us in fighting food waste and hunger
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleRegister} className="space-y-6">
              {/* Role Selection */}
              <div className="space-y-3">
                <Label>I am a...</Label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {roles.map((roleOption) => {
                    const Icon = roleOption.icon;
                    const isSelected = role === roleOption.value;
                    return (
                      <button
                        key={roleOption.value}
                        type="button"
                        onClick={() => setRole(roleOption.value as any)}
                        className={`p-4 rounded-lg border-2 transition-all text-left ${
                          isSelected
                            ? roleOption.color + ' border-2'
                            : 'bg-white border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className={`w-6 h-6 mb-2 ${isSelected ? roleOption.color.split(' ')[0] : 'text-gray-400'}`} />
                        <div className="font-semibold text-gray-900">{roleOption.label}</div>
                        <div className="text-xs text-gray-600 mt-1">{roleOption.description}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name">
                  {role === 'donor' || role === 'ngo' ? 'Organization Name' : 'Full Name'}
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    placeholder={role === 'donor' ? 'e.g., Green Valley Restaurant' : 'e.g., John Doe'}
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Create a strong password"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Terms */}
              <div className="text-xs text-gray-600">
                By registering, you agree to our{' '}
                <a href="#" className="text-green-600 hover:underline">
                  Terms of Service
                </a>{' '}
                and{' '}
                <a href="#" className="text-green-600 hover:underline">
                  Privacy Policy
                </a>
                .
              </div>

              {/* Register Button */}
              <Button
                type="submit"
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                size="lg"
              >
                Create Account
              </Button>

              {/* Login Link */}
              <div className="text-center text-sm">
                <span className="text-gray-600">Already have an account? </span>
                <Link to="/login" className="text-green-600 hover:text-green-700 font-medium">
                  Login here
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
