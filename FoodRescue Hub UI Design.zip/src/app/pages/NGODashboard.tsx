import { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { MapPin, Clock, Package, Filter, CheckCircle } from 'lucide-react';
import L from 'leaflet';

// Fix for default marker icons in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface FoodListing {
  id: string;
  foodType: string;
  quantity: string;
  donor: string;
  location: string;
  coordinates: [number, number];
  distance: number;
  expiryTime: string;
  notes: string;
  urgency: 'high' | 'medium' | 'low';
  status: 'available' | 'accepted';
}

export function NGODashboard() {
  const [viewMode, setViewMode] = useState<'map' | 'list'>('list');
  const [filterDistance, setFilterDistance] = useState<string>('all');
  const [filterFoodType, setFilterFoodType] = useState<string>('all');
  const [filterUrgency, setFilterUrgency] = useState<string>('all');

  const [listings, setListings] = useState<FoodListing[]>([
    {
      id: '1',
      foodType: 'Prepared Meals',
      quantity: '50 servings',
      donor: 'Green Valley Restaurant',
      location: '123 Main St, Downtown',
      coordinates: [40.7128, -74.0060],
      distance: 1.2,
      expiryTime: '2026-02-05T20:00',
      notes: 'Fresh pasta and salad from dinner service',
      urgency: 'high',
      status: 'available',
    },
    {
      id: '2',
      foodType: 'Bakery Items',
      quantity: '30 items',
      donor: 'Sweet Delights Bakery',
      location: '456 Oak Ave, Midtown',
      coordinates: [40.7580, -73.9855],
      distance: 2.5,
      expiryTime: '2026-02-06T10:00',
      notes: 'Assorted pastries and bread',
      urgency: 'medium',
      status: 'available',
    },
    {
      id: '3',
      foodType: 'Fresh Produce',
      quantity: '20 kg',
      donor: 'Grand Hotel Banquet',
      location: '789 Pine Rd, Uptown',
      coordinates: [40.7489, -73.9680],
      distance: 3.8,
      expiryTime: '2026-02-07T18:00',
      notes: 'Various vegetables from event catering',
      urgency: 'low',
      status: 'available',
    },
    {
      id: '4',
      foodType: 'Packaged Food',
      quantity: '100 items',
      donor: 'City Convention Center',
      location: '321 Market St, Downtown',
      coordinates: [40.7060, -74.0090],
      distance: 0.8,
      expiryTime: '2026-02-10T23:59',
      notes: 'Unopened snacks and beverages from conference',
      urgency: 'low',
      status: 'available',
    },
  ]);

  const handleAcceptPickup = (id: string) => {
    setListings(listings.map(listing => 
      listing.id === id ? { ...listing, status: 'accepted' } : listing
    ));
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'medium':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'low':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const filteredListings = listings.filter(listing => {
    if (filterDistance !== 'all') {
      const maxDistance = parseFloat(filterDistance);
      if (listing.distance > maxDistance) return false;
    }
    if (filterFoodType !== 'all' && listing.foodType !== filterFoodType) return false;
    if (filterUrgency !== 'all' && listing.urgency !== filterUrgency) return false;
    return true;
  });

  const centerCoordinates: [number, number] = [40.7128, -74.0060];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">NGO/Volunteer Dashboard</h1>
          <p className="text-gray-600">Find and accept food donations in your area</p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-600" />
              <CardTitle>Filters</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* View Mode Toggle */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">View Mode</label>
                <div className="flex gap-2">
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className={viewMode === 'list' ? 'bg-green-600 hover:bg-green-700' : ''}
                  >
                    List
                  </Button>
                  <Button
                    variant={viewMode === 'map' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('map')}
                    className={viewMode === 'map' ? 'bg-green-600 hover:bg-green-700' : ''}
                  >
                    Map
                  </Button>
                </div>
              </div>

              {/* Distance Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Distance</label>
                <Select value={filterDistance} onValueChange={setFilterDistance}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All distances</SelectItem>
                    <SelectItem value="1">Within 1 km</SelectItem>
                    <SelectItem value="2">Within 2 km</SelectItem>
                    <SelectItem value="5">Within 5 km</SelectItem>
                    <SelectItem value="10">Within 10 km</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Food Type Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Food Type</label>
                <Select value={filterFoodType} onValueChange={setFilterFoodType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="Prepared Meals">Prepared Meals</SelectItem>
                    <SelectItem value="Bakery Items">Bakery Items</SelectItem>
                    <SelectItem value="Fresh Produce">Fresh Produce</SelectItem>
                    <SelectItem value="Packaged Food">Packaged Food</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Urgency Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Urgency</label>
                <Select value={filterUrgency} onValueChange={setFilterUrgency}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All urgencies</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Count */}
        <div className="mb-4 text-sm text-gray-600">
          Showing {filteredListings.length} available listing{filteredListings.length !== 1 ? 's' : ''}
        </div>

        {/* Map View */}
        {viewMode === 'map' && (
          <Card className="mb-6">
            <CardContent className="p-0">
              <div className="h-96 md:h-[500px] rounded-lg overflow-hidden">
                <MapContainer
                  center={centerCoordinates}
                  zoom={13}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  {filteredListings.map((listing) => (
                    <Marker key={listing.id} position={listing.coordinates}>
                      <Popup>
                        <div className="p-2">
                          <h3 className="font-semibold mb-1">{listing.foodType}</h3>
                          <p className="text-sm text-gray-600 mb-1">{listing.donor}</p>
                          <p className="text-sm mb-2">{listing.quantity}</p>
                          <Badge className={getUrgencyColor(listing.urgency) + ' text-xs'}>
                            {listing.urgency} urgency
                          </Badge>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                </MapContainer>
              </div>
            </CardContent>
          </Card>
        )}

        {/* List View */}
        <div className="space-y-4">
          {filteredListings.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No listings match your filters. Try adjusting them.</p>
              </CardContent>
            </Card>
          ) : (
            filteredListings.map((listing) => (
              <Card key={listing.id}>
                <CardContent className="pt-6">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {listing.foodType}
                          </h3>
                          <p className="text-sm text-gray-600">{listing.donor}</p>
                        </div>
                        <Badge className={getUrgencyColor(listing.urgency)}>
                          {listing.urgency} urgency
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-600 mb-3">
                        <div className="flex items-center gap-2">
                          <Package className="w-4 h-4" />
                          <span>{listing.quantity}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{listing.distance} km away</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{listing.location}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>Best before: {new Date(listing.expiryTime).toLocaleString()}</span>
                        </div>
                      </div>

                      {listing.notes && (
                        <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                          {listing.notes}
                        </p>
                      )}
                    </div>

                    <div className="lg:ml-4">
                      {listing.status === 'available' ? (
                        <Button
                          onClick={() => handleAcceptPickup(listing.id)}
                          className="bg-green-600 hover:bg-green-700 w-full lg:w-auto"
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Accept Pickup
                        </Button>
                      ) : (
                        <Badge className="bg-orange-100 text-orange-700 border-orange-200 px-4 py-2">
                          Accepted
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
