import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { CheckCircle2, Circle, Clock, MapPin, User, Package } from 'lucide-react';

interface TrackingItem {
  id: string;
  foodType: string;
  quantity: string;
  donor: string;
  recipient: string;
  currentStatus: 'posted' | 'accepted' | 'picked-up' | 'delivered';
  timeline: {
    status: string;
    timestamp: string;
    completed: boolean;
  }[];
}

export function TrackingPage() {
  const [trackingItems] = useState<TrackingItem[]>([
    {
      id: '1',
      foodType: 'Prepared Meals',
      quantity: '50 servings',
      donor: 'Green Valley Restaurant',
      recipient: 'Hope Foundation NGO',
      currentStatus: 'picked-up',
      timeline: [
        { status: 'Posted', timestamp: '2026-02-05T15:30:00', completed: true },
        { status: 'Accepted', timestamp: '2026-02-05T16:15:00', completed: true },
        { status: 'Picked Up', timestamp: '2026-02-05T17:00:00', completed: true },
        { status: 'Delivered', timestamp: '', completed: false },
      ],
    },
    {
      id: '2',
      foodType: 'Bakery Items',
      quantity: '30 items',
      donor: 'Sweet Delights Bakery',
      recipient: 'Community Kitchen',
      currentStatus: 'accepted',
      timeline: [
        { status: 'Posted', timestamp: '2026-02-05T16:00:00', completed: true },
        { status: 'Accepted', timestamp: '2026-02-05T16:45:00', completed: true },
        { status: 'Picked Up', timestamp: '', completed: false },
        { status: 'Delivered', timestamp: '', completed: false },
      ],
    },
    {
      id: '3',
      foodType: 'Fresh Produce',
      quantity: '20 kg',
      donor: 'Grand Hotel Banquet',
      recipient: 'Food for All',
      currentStatus: 'delivered',
      timeline: [
        { status: 'Posted', timestamp: '2026-02-04T12:00:00', completed: true },
        { status: 'Accepted', timestamp: '2026-02-04T13:00:00', completed: true },
        { status: 'Picked Up', timestamp: '2026-02-04T14:30:00', completed: true },
        { status: 'Delivered', timestamp: '2026-02-04T16:00:00', completed: true },
      ],
    },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'posted':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'accepted':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'picked-up':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getProgress = (status: string) => {
    switch (status) {
      case 'posted':
        return 25;
      case 'accepted':
        return 50;
      case 'picked-up':
        return 75;
      case 'delivered':
        return 100;
      default:
        return 0;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    if (!timestamp) return '';
    return new Date(timestamp).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Food Pickup Tracking</h1>
          <p className="text-gray-600">Monitor the status of food donations in real-time</p>
        </div>

        {/* Tracking Items */}
        <div className="space-y-6">
          {trackingItems.map((item) => (
            <Card key={item.id}>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                  <div>
                    <CardTitle className="text-xl mb-1">{item.foodType}</CardTitle>
                    <CardDescription>{item.quantity}</CardDescription>
                  </div>
                  <Badge className={getStatusColor(item.currentStatus)}>
                    {item.currentStatus.replace('-', ' ').toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Progress</span>
                    <span>{getProgress(item.currentStatus)}%</span>
                  </div>
                  <Progress value={getProgress(item.currentStatus)} className="h-2" />
                </div>

                {/* Parties Involved */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-y border-gray-200">
                  <div className="flex items-start gap-3">
                    <div className="bg-green-100 p-2 rounded-lg">
                      <User className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Donor</p>
                      <p className="font-medium text-gray-900">{item.donor}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-orange-100 p-2 rounded-lg">
                      <Package className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Recipient</p>
                      <p className="font-medium text-gray-900">{item.recipient}</p>
                    </div>
                  </div>
                </div>

                {/* Timeline */}
                <div className="space-y-1">
                  <h4 className="font-medium text-gray-900 mb-4">Status Timeline</h4>
                  <div className="space-y-0">
                    {item.timeline.map((step, index) => (
                      <div key={index} className="relative flex gap-4 pb-8 last:pb-0">
                        {/* Connector Line */}
                        {index < item.timeline.length - 1 && (
                          <div
                            className={`absolute left-[15px] top-8 w-0.5 h-full ${
                              step.completed ? 'bg-green-500' : 'bg-gray-300'
                            }`}
                          />
                        )}

                        {/* Icon */}
                        <div className="relative flex-shrink-0">
                          {step.completed ? (
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-500">
                              <CheckCircle2 className="w-5 h-5 text-white" />
                            </div>
                          ) : (
                            <div className="flex items-center justify-center w-8 h-8 rounded-full border-2 border-gray-300 bg-white">
                              <Circle className="w-4 h-4 text-gray-300" />
                            </div>
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 pt-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p
                              className={`font-medium ${
                                step.completed ? 'text-gray-900' : 'text-gray-500'
                              }`}
                            >
                              {step.status}
                            </p>
                            {!step.completed && index === item.timeline.findIndex(s => !s.completed) && (
                              <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                                In Progress
                              </Badge>
                            )}
                          </div>
                          {step.timestamp && (
                            <div className="flex items-center gap-1 text-sm text-gray-600">
                              <Clock className="w-3.5 h-3.5" />
                              <span>{formatTimestamp(step.timestamp)}</span>
                            </div>
                          )}
                          {!step.completed && !step.timestamp && (
                            <p className="text-sm text-gray-500">Pending</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {trackingItems.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No active tracking items</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
