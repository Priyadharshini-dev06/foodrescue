
  # FoodRescue Hub UI Design

  This is a code bundle for FoodRescue Hub UI Design. The original project is available at https://www.figma.com/design/A8eZxIl5ZWaFCVSg8lttvC/FoodRescue-Hub-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  